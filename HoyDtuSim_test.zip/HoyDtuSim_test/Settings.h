#ifndef __SETTINGS_H
#define __SETTINGS_H

// Ausgabe von Debug Infos auf der seriellen Console
#define DEBUG
#define SER_BAUDRATE            (115200)

#include "Debug.h"

// Hardware configuration


#define RF1_CE_PIN  (D4)
#define RF1_CS_PIN  (D8)
#define RF1_IRQ_PIN (D3)


#define PA_LEVEL    RF24_PA_LOW         // RF24_PA_MAX


// WR und DTU
#define RF_MAX_ADDR_WIDTH       (5) 
#define MAX_RF_PAYLOAD_SIZE     (32)
#define DEFAULT_RF_DATARATE     (RF24_250KBPS)  // Datarate

// Ausgabe was gesendet wird; 0 oder 1 
#define DEBUG_SEND  1   

// soll zwichen den Sendekanälen 23, 40, 61, 75 ständig gewechselt werden
#define CHANNEL_HOP
#define USE_POOR_MAN_CHANNEL_HOPPING_RCV  1     // 0 = not use

#define DUMMY_RADIO_ID          ((uint64_t)0xDEADBEEF01ULL) 
#define DTU_RADIO_ID            ((uint64_t)0x1234567801ULL)  //GB ?? die gespiegelte (letzte 4 "Bytes") der Seriennummer
#define MAX_MEASURE_PER_INV 25    // hier statisch, könnte auch dynamisch erzeugt werden, aber Overhead für dyn. Speicher?

#define MAX_ANZ_INV             1                       // <<<<<< anpassen oder dyn.
#define POLL_INTERVALL_WR       10                      // für jeden WR
uint16_t WAIT_TILL_NEXT_SEND;

#include "Inverters.h"


#include "HM400.h"                            // <<<<<< anpassen und folgende Defs
#define WR1_NAME "HM-400"
#define WR1_SERIAL 0x112181311702ULL   //GB !! Serial eintragen!!
#define WR1_MEASUREDEF hm400_measureDef
#define WR1_MEASURECALC hm400_measureCalc
#define WR1_FRAGMENTS hm400_fragmentLen
uint16_t WR1_MODULEPEAKS[] = {1,300};


#define TEST_MULTI 1

void setupInverters() {
//-----------------  

  addInverter (anzInv, WR1_NAME, WR1_SERIAL,    
               WR1_MEASUREDEF, sizeof(WR1_MEASUREDEF) / sizeof(measureDef_t),
               WR1_MEASURECALC, sizeof(WR1_MEASURECALC) / sizeof(measureCalc_t),
               WR1_FRAGMENTS,
               WR1_MODULEPEAKS);


  WAIT_TILL_NEXT_SEND = POLL_INTERVALL_WR / anzInv;
  if (WAIT_TILL_NEXT_SEND < 5) 
    WAIT_TILL_NEXT_SEND = 5;
  WAIT_TILL_NEXT_SEND=10;  
}

#endif
